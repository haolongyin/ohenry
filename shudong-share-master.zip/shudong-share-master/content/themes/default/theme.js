function danru(){
	$("#logo").fadeIn();

     }