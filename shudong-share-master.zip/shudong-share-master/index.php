<script>
window.location="install";

</script>