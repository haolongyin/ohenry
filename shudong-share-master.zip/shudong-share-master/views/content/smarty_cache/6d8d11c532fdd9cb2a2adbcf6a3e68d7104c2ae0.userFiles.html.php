<?php /*%%SmartyHeaderCode:565757253f5295f999-19508096%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6d8d11c532fdd9cb2a2adbcf6a3e68d7104c2ae0' => 
    array (
      0 => '.\\..\\content\\themes\\default\\userFiles.html',
      1 => 1462000334,
      2 => 'file',
    ),
    '1ac98cd00e360cd2c56bcca592c3af81e1b582a6' => 
    array (
      0 => '.\\..\\content\\themes\\default\\userIndexSide.html',
      1 => 1454722784,
      2 => 'file',
    ),
    '6b0bb0bf5ec21ef34127aba09a1f27a33aa1cbb6' => 
    array (
      0 => '.\\..\\content\\themes\\default\\head.html',
      1 => 1454667278,
      2 => 'file',
    ),
    'f9a31bb18afe6f504b3094ef7642539f0b025d6a' => 
    array (
      0 => '.\\..\\content\\themes\\default\\footer.html',
      1 => 1454502542,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '565757253f5295f999-19508096',
  'variables' => 
  array (
    'tit' => 0,
    'head' => 0,
    'zzurl' => 0,
    'isVisitor' => 0,
    'userinfo' => 0,
    'filedata' => 0,
    'jscode' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_57253f52a1b5d6_99657114',
  'cache_lifetime' => 3600,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57253f52a1b5d6_99657114')) {function content_57253f52a1b5d6_99657114($_smarty_tpl) {?><title>我的文件 - 树洞外链</title> 
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head> 
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 


  
  <link rel="stylesheet" href="../content/themes/default/bootstrap/css/bootstrap.css" /> 
  <link rel="stylesheet" href="../content/themes/default/bootstrap/css/style_u.css" /> 
    <link rel="stylesheet" href="../content/themes/default/bootstrap/css/lock.css" /> 
      <link rel="stylesheet" href="../content/themes/default/bootstrap/css/iosOverlay.css" /> 
 </head> 
 <body>
   <script type="text/javascript" src="./../includes/js/jquery-1.9.1.min.js"></script> 
  <script type="text/javascript" src="../content/themes/default/bootstrap/js/bootstrap.min.js"></script> 
  <script type="text/javascript" src="../content/themes/default/js/ZeroClipboard.js"></script> 
    <script type="text/javascript" src="../content/themes/default/js/iosOverlay.js"></script>
        <script type="text/javascript" src="../content/themes/default/js/else.js"></script>
  <style type="text/css">
 body {
  background-image: url(../content/themes/default/images/bg.png);
  background-repeat: repeat-x;
  background-color: #9cd9f2;
  margin-top:36px;
font-family: '微软雅黑';

}
a{
  color: #444444  ;
}
.xiaoguo{box-shadow: 0px 0px 30px #888888;}
body, dl, dt, dd, ul, ol, li, h1, h2, h3, h4, h5, h6, pre, form, fieldset, textarea, p, blockquote, th, td { padding: 0; margin: 0; }
</style> 
<div>
<nav class="navbar navbar-default navbar-fixed-top">
 <div class="container">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a href="http://127.0.0.1/"><img src="http://127.0.0.1//content/themes/default/images/logo_s.png"></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
       <!-- 你可以在这里添加靠左边的导航   -->
      </ul>
     
      <ul class="nav navbar-nav navbar-right">
        <li><a href="http://127.0.0.1/"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> 首页</a></li>
                <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="
glyphicon glyphicon-plus" aria-hidden="true"></span> 其他 <span class="caret"></span></a>
          <ul class="dropdown-menu">
          <!-- 以下链接可以根据自己需要更改 -->
            <li><a href="#">帮助</a></li>
            <li><a href="#">使用须知</a></li>
            <li><a href="#">捐助我们</a></li>

            <li><a href="#">讨论区</a></li>
          </ul>
        </li>
                 <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="
glyphicon glyphicon-user" aria-hidden="true"></span> abslant@126.com <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="http://127.0.0.1//views/userIndex.php">用户中心</a></li>
            <li><a href="http://127.0.0.1//includes/userAction.php?action=logout">登出</a></li>
          </ul>
        </li>
        
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
 </div>
</nav>

    <br /> 
   <br /> 
   <br /> 

   <br />  <br /> 
<div class="container">
<div class="row">
 <div class="list-group-block col-md-2 zhu">
                <div class="list-group-panel">


<br>
                  
                <ul class="list-group">
                                
                  <a class="list-group-item " href="userIndex.php"><i class="glyphicon glyphicon-home"></i> 个人主页</a>
                  
                  <a class="list-group-item " href="userFiles.php"><i class="glyphicon glyphicon-file"></i> 我的文件</a>
                  
                  <a class="list-group-item " href="userShares.php"><i class="glyphicon glyphicon-cloud"></i> 公开分享</a>
                  <a class="list-group-item " href="userSharesS.php"><i class="glyphicon glyphicon-eye-close"></i> 私密分享</a>

                               
                  <a class="list-group-item " href="userPassWord.php"><i class="glyphicon glyphicon-lock"></i> 修改密码</a>

                                  <a class="list-group-item " href="../includes/userAction.php?action=logout"><i class="glyphicon glyphicon-circle-arrow-right"></i> 退出登录</a>
                  
                </ul>
              </div>

                    

                     

                
              </div>
<script type="text/javascript">
 var linkname = window.location.pathname.split('/');
var linknow = linkname[linkname.length-1].split("?");
 $("a[href='"+linknow+"']").addClass("active");
</script>
              <div class="col-md-10">
                <div class="zhu">
                  <div class="row">
                  <div class="col-md-12">
                    <h1 class="page-header">  我的文件</h1>
                    </div>
                  </div>
                  <div class="row">

                  <div class="col-md-12" style="margin-left: 20px;">
                  <table class="table table-hover table-bordered "style="width: 96%">
<thead>
        <tr>
        <th> <input type="checkbox" onclick="selectAll(this);"  /></th>
          <th >文件名</th>
          <th>上传日期</th>
          <th>操作</th>
        </tr>
      </thead>

         
          <tbody>

  
 <tr> 
<td><input type="checkbox"name="file"value="d4dda25497b86de725813f86df0693d8"  /></th></td>
 <td><a target="_blank"href="http://127.0.0.1//views/fileJump.php?key=d4dda25497b86de725813f86df0693d8&ming=360截图20151219083702239.png">360截图20151219083702239.png</a></td><td>2016-05-01 07:27:04</td> 
 <td><button onclick="delfile('d4dda25497b86de725813f86df0693d8');"class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i> 删除</button></td></td>
  
 <tr> 
<td><input type="checkbox"name="file"value="176411f87352d151a6ff6d71fd3f7488"  /></th></td>
 <td><a target="_blank"href="http://127.0.0.1//views/fileJump.php?key=176411f87352d151a6ff6d71fd3f7488&ming=kkey">kkey</a></td><td>2016-04-30 12:41:48</td> 
 <td><button onclick="delfile('176411f87352d151a6ff6d71fd3f7488');"class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i> 删除</button></td></td>
  
 <tr> 
<td><input type="checkbox"name="file"value="9029b921d1c9eef79bd2e4ccadbdcc3c"  /></th></td>
 <td><a target="_blank"href="http://127.0.0.1//views/fileJump.php?key=9029b921d1c9eef79bd2e4ccadbdcc3c&ming=yuancheng_2016022814571449577539.mp3">yuancheng_2016022814571449577539.mp3</a></td><td>2016-02-28 14:57:15</td> 
 <td><button onclick="delfile('9029b921d1c9eef79bd2e4ccadbdcc3c');"class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i> 删除</button></td></td>
  </tbody></table>
<button onclick="delall();"id="s"class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i> 删除选中文件</button><br><br>
        </div>
            </div>

                </div>
              </div>
</div>
              </div><!--con -->
  <br>  <br>  <br>  <br>  <br>
  

<br><br><br>
    <footer class="footer" style="background-image: url(http://127.0.0.1/content/themes/default/images/footer.png);background-repeat: repeat-x;
">
      <div class="container"> 
        <p class="text-muted">Copyright &copy; 2016 树洞外链  Powerd by <a target="_blank" href="http://aoaoao.me">树洞外链</a>  </p>
      </div>
    </footer>
  <script language="JavaScript"> 
  function delall(){
     var chk_value =[];//定义一个数组    
            $('input[name="file"]:checked').each(function(){  
            chk_value.push($(this).val());   
            });
            $("#s").attr("disabled","true");
            for(key1 in chk_value){ 
               $.ajax({
             type: "POST",
             url: "../includes/delete_file.php",
             data: {key: chk_value[key1]},
             dataType: "text",
             async: false,
             success: function(data){
    var pe=data.split(".");
    if(pe[0]=="ok"){ 

    }else{ 
alert("删除时遇到错误");


 };

                      }
         });
         
            }
            $("#ss").removeAttr("disabled");
            window.location.reload();
  } 
 function delfile(key1) {
   
$.post("../includes/delete_file.php",{key: key1},
  function(data){
    var pe=data.split(".");
    if(pe[0]=="ok"){ 
alert(pe[1]);
window.location.reload();
    }else{ 
alert(pe[1]);


 };

});}
 function selectAll(checkbox) {
                $('input[type=checkbox]').prop('checked', $(checkbox).prop('checked'));
            }
</script>  
 </body>
</html><?php }} ?>
