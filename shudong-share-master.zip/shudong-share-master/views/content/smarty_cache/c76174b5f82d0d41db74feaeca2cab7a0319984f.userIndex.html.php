<?php /*%%SmartyHeaderCode:2493157253f506e1b11-77080520%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c76174b5f82d0d41db74feaeca2cab7a0319984f' => 
    array (
      0 => '.\\..\\content\\themes\\default\\userIndex.html',
      1 => 1454726034,
      2 => 'file',
    ),
    '1ac98cd00e360cd2c56bcca592c3af81e1b582a6' => 
    array (
      0 => '.\\..\\content\\themes\\default\\userIndexSide.html',
      1 => 1454722784,
      2 => 'file',
    ),
    '6b0bb0bf5ec21ef34127aba09a1f27a33aa1cbb6' => 
    array (
      0 => '.\\..\\content\\themes\\default\\head.html',
      1 => 1454667278,
      2 => 'file',
    ),
    'f9a31bb18afe6f504b3094ef7642539f0b025d6a' => 
    array (
      0 => '.\\..\\content\\themes\\default\\footer.html',
      1 => 1454502542,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2493157253f506e1b11-77080520',
  'variables' => 
  array (
    'tit' => 0,
    'head' => 0,
    'zzurl' => 0,
    'isVisitor' => 0,
    'userinfo' => 0,
    'filenum' => 0,
    'sharenum' => 0,
    'mailhash' => 0,
    'gname' => 0,
    'jscode' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_57253f507b9984_40121747',
  'cache_lifetime' => 3600,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57253f507b9984_40121747')) {function content_57253f507b9984_40121747($_smarty_tpl) {?><title>用户中心 - 树洞外链</title> 
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head> 
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 


  
  <link rel="stylesheet" href="../content/themes/default/bootstrap/css/bootstrap.css" /> 
  <link rel="stylesheet" href="../content/themes/default/bootstrap/css/style_u.css" /> 
    <link rel="stylesheet" href="../content/themes/default/bootstrap/css/lock.css" /> 
      <link rel="stylesheet" href="../content/themes/default/bootstrap/css/iosOverlay.css" /> 
 </head> 
 <body>
   <script type="text/javascript" src="./../includes/js/jquery-1.9.1.min.js"></script> 
  <script type="text/javascript" src="../content/themes/default/bootstrap/js/bootstrap.min.js"></script> 
  <script type="text/javascript" src="../content/themes/default/js/ZeroClipboard.js"></script> 
    <script type="text/javascript" src="../content/themes/default/js/iosOverlay.js"></script>
        <script type="text/javascript" src="../content/themes/default/js/else.js"></script>
  <style type="text/css">
 body {
  background-image: url(../content/themes/default/images/bg.png);
  background-repeat: repeat-x;
  background-color: #9cd9f2;
  margin-top:36px;
font-family: '微软雅黑';

}
a{
  color: #444444  ;
}
.xiaoguo{box-shadow: 0px 0px 30px #888888;}
body, dl, dt, dd, ul, ol, li, h1, h2, h3, h4, h5, h6, pre, form, fieldset, textarea, p, blockquote, th, td { padding: 0; margin: 0; }
</style> 
<div>
<nav class="navbar navbar-default navbar-fixed-top">
 <div class="container">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a href="http://127.0.0.1/"><img src="http://127.0.0.1//content/themes/default/images/logo_s.png"></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
       <!-- 你可以在这里添加靠左边的导航   -->
      </ul>
     
      <ul class="nav navbar-nav navbar-right">
        <li><a href="http://127.0.0.1/"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> 首页</a></li>
                <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="
glyphicon glyphicon-plus" aria-hidden="true"></span> 其他 <span class="caret"></span></a>
          <ul class="dropdown-menu">
          <!-- 以下链接可以根据自己需要更改 -->
            <li><a href="#">帮助</a></li>
            <li><a href="#">使用须知</a></li>
            <li><a href="#">捐助我们</a></li>

            <li><a href="#">讨论区</a></li>
          </ul>
        </li>
                 <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="
glyphicon glyphicon-user" aria-hidden="true"></span> abslant@126.com <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="http://127.0.0.1//views/userIndex.php">用户中心</a></li>
            <li><a href="http://127.0.0.1//includes/userAction.php?action=logout">登出</a></li>
          </ul>
        </li>
        
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
 </div>
</nav>

    <br /> 
   <br /> 
   <br /> 

   <br />  <br /> 
<div class="container">
<div class="row">
 <div class="list-group-block col-md-2 zhu">
                <div class="list-group-panel">


<br>
                  
                <ul class="list-group">
                                
                  <a class="list-group-item " href="userIndex.php"><i class="glyphicon glyphicon-home"></i> 个人主页</a>
                  
                  <a class="list-group-item " href="userFiles.php"><i class="glyphicon glyphicon-file"></i> 我的文件</a>
                  
                  <a class="list-group-item " href="userShares.php"><i class="glyphicon glyphicon-cloud"></i> 公开分享</a>
                  <a class="list-group-item " href="userSharesS.php"><i class="glyphicon glyphicon-eye-close"></i> 私密分享</a>

                               
                  <a class="list-group-item " href="userPassWord.php"><i class="glyphicon glyphicon-lock"></i> 修改密码</a>

                                  <a class="list-group-item " href="../includes/userAction.php?action=logout"><i class="glyphicon glyphicon-circle-arrow-right"></i> 退出登录</a>
                  
                </ul>
              </div>

                    

                     

                
              </div>
<script type="text/javascript">
 var linkname = window.location.pathname.split('/');
var linknow = linkname[linkname.length-1].split("?");
 $("a[href='"+linknow+"']").addClass("active");
</script>
              <div class="col-md-10">
                <div class="zhu">
                  <div class="row">
                  <div class="col-md-12">
                    <h1 class="page-header">  欢迎您,abslant@126.com</h1>
                    </div>
                  </div>
                  <div class="row">
                <div class="col-lg-3 col-md-6" style="margin-left: 20px;">
                    <div class="panel panel-primary">
                        <div class="panel-heading" style="height: 114px;">
                            <div class="row">
                                <div class="col-xs-3">
                                    <div style="font-size: 70px;"><i  class="glyphicon glyphicon-file"></i></div>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">3</div>
                                    <div>我的文件</div>
                                </div>
                            </div>
                        </div>
                        <a href="userFiles.php">
                            <div class="panel-footer" style="color:#428bca  ">
                                <span class="pull-left" herf="userFiles.php">查看详情</span>
                                <span class="pull-right"><i class="glyphicon glyphicon-circle-arrow-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
               
                <div class="col-lg-3 col-md-6" >
                    <div class="panel panel-green">
                        <div class="panel-heading" style="height: 114px;">
                            <div class="row">
                                <div class="col-xs-3">
                                    <div style="font-size: 70px;"><i  class="glyphicon glyphicon-cloud"></i></div>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">0</div>
                                    <div>我的分享</div>
                                </div>
                            </div>
                        </div>
                        <a href="userFiles.php">
                            <div class="panel-footer" style="color: #5cb85c;">
                                <span class="pull-left" herf="userShares.php">查看详情</span>
                                <span class="pull-right"><i class="glyphicon glyphicon-circle-arrow-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
               <div class="col-lg-5 col-md-11" >
                  <div class="panel panel-default">
  <div class="panel-body">
    <div class="info-left"><img src="https://secure.gravatar.com/avatar/3800f67051ba9440ffecf2c3e8734933?s=69&r=g" alt="..." class="img-circle">
  </div>
  <div class="info-right">
    <div ><strong>注册邮箱：</strong>abslant@126.com<br>
        <strong>UID：</strong>1  <br><strong>注册日期：</strong>2016-02-28 05:59:16<br><strong>用户组：</strong>高级会员<br>
    </div>
  </div>
  </div>
  <div class="panel-footer" align="right">用户信息</div>
</div>
                </div>
            </div>

                </div>
              </div>
</div>
              </div><!--con -->
  <br>  <br>  <br>  <br>  <br>
  

<br><br><br>
    <footer class="footer" style="background-image: url(http://127.0.0.1/content/themes/default/images/footer.png);background-repeat: repeat-x;
">
      <div class="container"> 
        <p class="text-muted">Copyright &copy; 2016 树洞外链  Powerd by <a target="_blank" href="http://aoaoao.me">树洞外链</a>  </p>
      </div>
    </footer>
  <script language="JavaScript">  
 
</script>  
 </body>
</html><?php }} ?>
