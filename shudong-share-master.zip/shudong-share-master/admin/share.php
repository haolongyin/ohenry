<?php

error_reporting(0);//设置错误级别0

require_once("../config.php");//引入配置文件
require_once('../includes/function.php');//引入函数库
require_once("../includes/connect.php");
require_once("../includes/usercheck.php");
$title="分享管理";
require_once("common/head.php");


?>
<body>

      
        <div id="page-wrapper">
           

  
    <div class="rows">
    <!-- /#wrapper -->
<iframe src="share_ss.php?page=1"frameborder="0" scrolling="no"height="1000"width="100%"></iframe>
    <!-- jQuery -->

</div>  </div>
</body>

</html>
